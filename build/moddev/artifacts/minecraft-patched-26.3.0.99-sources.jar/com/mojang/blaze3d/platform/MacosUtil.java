package com.mojang.blaze3d.platform;

import ca.weblite.objc.Client;
import ca.weblite.objc.Proxy;
import java.util.Set;
import net.minecraft.util.Util;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.sdl.SDLHints;
import org.lwjgl.system.macosx.ObjCRuntime;

@OnlyIn(Dist.CLIENT)
public final class MacosUtil {
    public static final boolean IS_MACOS = Util.getPlatform() == Util.OS.OSX;

    private MacosUtil() {
    }

    public static void disableCloseWindowMenuItem() {
        if (IS_MACOS) {
            Proxy windowsMenu = Client.getInstance().sendProxy("NSApplication", "sharedApplication").sendProxy("windowsMenu");
            int itemCount = windowsMenu.sendInt("numberOfItems");

            for (int i = 0; i < itemCount; i++) {
                Proxy item = windowsMenu.sendProxy("itemAtIndex:", i);
                if (MacosUtil.DisabledActions.SELECTORS.contains((Long)item.sendRaw("action"))) {
                    item.send("setEnabled:", false);
                    item.send("setHidden:", true);
                    item.send("setKeyEquivalent:", "");
                }
            }
        }
    }

    public static void setFullscreenMenuVisibility(boolean value) {
        if (IS_MACOS) {
            SDLHints.SDL_SetHint("SDL_VIDEO_MAC_FULLSCREEN_MENU_VISIBILITY", value ? "1" : "0");
        }
    }

    public static void setCtrlClickEmulatesRightClick(boolean value) {
        if (IS_MACOS) {
            SDLHints.SDL_SetHint("SDL_MAC_CTRL_CLICK_EMULATE_RIGHT_CLICK", value ? "1" : "0");
        }
    }

    private static final class DisabledActions {
        private static final Set<Long> SELECTORS = Set.of(ObjCRuntime.sel_getUid("performClose:"), ObjCRuntime.sel_getUid("closeAll:"));
    }
}
